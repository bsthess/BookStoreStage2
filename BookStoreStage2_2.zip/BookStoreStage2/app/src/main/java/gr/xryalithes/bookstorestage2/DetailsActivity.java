package gr.xryalithes.bookstorestage2;


import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.LoaderManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.CursorLoader;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.Loader;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.text.NumberFormat;
import java.util.Locale;


import gr.xryalithes.bookstorestage2.Data.BookContract.BookData;


public class DetailsActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Cursor> {
    private static final int MAXIMUM_ALLOWED_PRICE = 100;
    private static final int MINIMUM_ALLOWED_PRICE = 1;
    private static final int MAXIMUM_ALLOWED_QUANTITY = 100;
    private static final int MINIMUM_ALLOWED_QUANTITY = 0;
    private static final int EXISTING_BOOK_LOADER = 0;
    public ImageButton quantityPlusButton;
    public ImageButton quantityMinusButton;
    private Uri mCurrentBookUri;
    private EditText mTitleEditText;
    private EditText mPriceEditText;
    private TextView mQuantityTextView;
    private EditText mSupplierNameEditText;
    private EditText mSupplierPhoneEditText;
    private boolean mBookHasChanged = false;
    private FloatingActionButton deleteFloatingButton;
    private FloatingActionButton makeOrderFloatingButton;
    /**
     * OnTouchListener that listens for any user touches on a View, implying that they are modifying
     * the view, and we change the mbookHasChanged boolean to true.
     */
    private View.OnTouchListener mTouchListener = new View.OnTouchListener() {
        @Override
        public boolean onTouch(View view, MotionEvent Event) {
            mBookHasChanged = true;
            return false;
        }
    };

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        setTitle(getString(R.string.details_activity_title));

        Intent intent = getIntent();
        mCurrentBookUri = intent.getData();

        getLoaderManager().initLoader(EXISTING_BOOK_LOADER, null, this);


        mTitleEditText = findViewById(R.id.edit_book_title);
        mPriceEditText = findViewById(R.id.edit_book_price);
        mQuantityTextView = findViewById(R.id.edit_book_quantity);
        mSupplierNameEditText = findViewById(R.id.edit_supplier_name);
        mSupplierPhoneEditText = findViewById(R.id.edit_supplier_phone);
        quantityPlusButton = findViewById(R.id.quantity_plus_button);
        deleteFloatingButton = findViewById(R.id.delete_floating_button);
        makeOrderFloatingButton = findViewById(R.id.call_floating_button);

        mTitleEditText.setOnTouchListener(mTouchListener);
        mPriceEditText.setOnTouchListener(mTouchListener);
        mQuantityTextView.setOnTouchListener(mTouchListener);
        mSupplierNameEditText.setOnTouchListener(mTouchListener);
        mSupplierPhoneEditText.setOnTouchListener(mTouchListener);
        quantityPlusButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                increaseQuantity();
            }
        });
        quantityMinusButton = findViewById(R.id.quantity_minus_button);
        quantityMinusButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                decreaseQuantity();
            }
        });

        deleteFloatingButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                showDeleteConfirmationDialog();
            }
        });
        makeOrderFloatingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String telnumber = mSupplierPhoneEditText.getText().toString();
                Intent intent = new Intent(Intent.ACTION_CALL);
                intent.setData(Uri.parse("tel:" + telnumber));
                if (ActivityCompat.checkSelfPermission(DetailsActivity.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    return;
                }
                startActivity(intent);

            }
        });
    }

    private void increaseQuantity() {
        int quantity = Integer.parseInt(mQuantityTextView.getText().toString());
        if (quantity <MAXIMUM_ALLOWED_QUANTITY) {
            quantity++;
            String quantityChanged = String.valueOf(quantity);
            mQuantityTextView.setText(quantityChanged);
            Toast.makeText(DetailsActivity.this, "Quantity increased", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(DetailsActivity.this, "Maximum quantity is/:"+MAXIMUM_ALLOWED_QUANTITY+" pcs", Toast.LENGTH_SHORT).show();
        }
    }

    private void decreaseQuantity() {
        int quantity = Integer.parseInt(mQuantityTextView.getText().toString());
        if (quantity > MINIMUM_ALLOWED_QUANTITY) {
            quantity--;
            String quantityChanged = String.valueOf(quantity);
            mQuantityTextView.setText(quantityChanged);
            Toast.makeText(DetailsActivity.this, "Quantity decreased", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(DetailsActivity.this, "Negative quantity not allowed", Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_details, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // User clicked on a menu option in the app bar overflow menu
        switch (item.getItemId()) {
            // Respond to a click on the "Save" menu option
            case R.id.action_done:
                dataValidation();
                return true;

            // Respond to a click on the "Up" arrow button in the app bar
            case android.R.id.home:
                // If the book hasn't changed, continue with navigating up to parent activity
                // which is the {@link CatalogActivity}.
                if (!mBookHasChanged) {
                    NavUtils.navigateUpFromSameTask(DetailsActivity.this);
                    return true;
                }

                // Otherwise if there are unsaved changes, setup a dialog to warn the user.
                // Create a click listener to handle the user confirming that
                // changes should be discarded.
                DialogInterface.OnClickListener discardButtonClickListener =
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                // User clicked "Discard" button, navigate to parent activity.
                                NavUtils.navigateUpFromSameTask(DetailsActivity.this);
                            }
                        };

                // Show a dialog that notifies the user they have unsaved changes
                showUnsavedBookDialog(discardButtonClickListener);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void dataValidation() {

        String titleString = mTitleEditText.getText().toString().trim();
        String priceString = mPriceEditText.getText().toString().trim();
        String quantityString = mQuantityTextView.getText().toString().trim();
        String supplierName = mSupplierNameEditText.getText().toString().trim();
        String supplierPhone = mSupplierPhoneEditText.getText().toString().trim();
        if (
                TextUtils.isEmpty(titleString) && TextUtils.isEmpty(priceString) &&
                        TextUtils.isEmpty(quantityString) && TextUtils.isEmpty(supplierName) && TextUtils.isEmpty(supplierPhone)) {
            return;
        }
        if (titleIsValid(titleString) && priceIsValid(priceString) && quantityIsValid(quantityString) &&
                supplierNameIsValid(supplierName) && supplierPhoneIsValid(supplierPhone)) {

            editbook();
        }

    }

    //////////////////////////////////////////////////////////////////////////////////////
    private boolean titleIsValid(String title) {
        if (title.isEmpty()) {

            Toast.makeText(this, getString(R.string.edit_text_title_empty),
                    Toast.LENGTH_SHORT).show();

            return false;
        }

        if (title.length() > 25) {
            mTitleEditText.setText("");
            Toast.makeText(this, getString(R.string.edit_text_title_maximum_characters),
                    Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    ///////////////////////////////////////////////////////////////////////////////////
    private boolean priceIsValid(String price) {
        if (price.isEmpty()) {
            Toast.makeText(DetailsActivity.this, R.string.price_not_allowed_msg, Toast.LENGTH_SHORT).show();
            Log.v("Price =",price);
            return false;
        }
        else {
            int priceInteger = Integer.parseInt(price);
            if(priceInteger<=0){
                Toast.makeText(DetailsActivity.this, R.string.price_minimum_msg, Toast.LENGTH_SHORT).show();
                mPriceEditText.setText(String.valueOf(MINIMUM_ALLOWED_PRICE));
                return false;
            }
            if (priceInteger > 100) {
                mPriceEditText.setText(String.valueOf(MAXIMUM_ALLOWED_PRICE));
                Toast.makeText(DetailsActivity.this, R.string.price_maximum_msg, Toast.LENGTH_SHORT).show();
                return false;
            }
        }
        return true;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////
    private boolean quantityIsValid(String quantity) {
        int quantityInteger = Integer.parseInt(mQuantityTextView.getText().toString());
        if (quantity.isEmpty()) {
            Toast.makeText(DetailsActivity.this, R.string.quantity_not_empty_msg, Toast.LENGTH_SHORT).show();
            mQuantityTextView.setText(0);
            return false;
        } else {
            if (quantityInteger > 100) {
                Toast.makeText(DetailsActivity.this, "Maximum quantity is 100 pcs", Toast.LENGTH_SHORT).show();
                return false;
            }
            return true;
        }
    }
    ////////////////////////////////////////////////////////////////////////////////////////////
    private boolean supplierNameIsValid(String supplierName) {
        if (supplierName.isEmpty()) {
            Toast.makeText(DetailsActivity.this, R.string.supplier_name_empty_msg, Toast.LENGTH_SHORT).show();
            return false;
        } else {
            if (supplierName.length() > 25) {
                Toast.makeText(DetailsActivity.this, R.string.supplier_name_max_25_char_msg, Toast.LENGTH_SHORT).show();
                return false;
            }
            return true;
        }
    }
    ////////////////////////////////////////////////////////////////////////////////////////////
    private boolean supplierPhoneIsValid(String supplierPhone) {
        if (supplierPhone.isEmpty()) {
            Toast.makeText(DetailsActivity.this, R.string.supplier_phone_empty_msg, Toast.LENGTH_SHORT).show();
            return false;
        } else {
            if (supplierPhone.length() < 10) {
                Toast.makeText(DetailsActivity.this, R.string.supplier_phone_10_digits_msg, Toast.LENGTH_SHORT).show();
                return false;
            }
            return true;
        }
    }
    /**
     * Get user input from editor and save book into database.
     */
    private void editbook() {
        // Read from input fields
        // Use trim to eliminate leading or trailing white space
        String titleString = mTitleEditText.getText().toString().trim();
        String priceString = mPriceEditText.getText().toString().trim();
        String quantityString = mQuantityTextView.getText().toString().trim();
        String supplierName = mSupplierNameEditText.getText().toString().trim();
        String supplierPhone = mSupplierPhoneEditText.getText().toString().trim();
        //////////////////////////////////////////////////////////////////////////////////////////
        ContentValues values = new ContentValues();
        values.put(BookData.COLUMN_BOOK_TITLE, titleString);
        values.put(BookData.COLUMN_BOOK_PRICE, priceString);
        values.put(BookData.COLUMN_BOOK_QUANTITY, quantityString);
        values.put(BookData.COLUMN_SUPPLIER_NAME, supplierName);
        values.put(BookData.COLUMN_SUPPLIER_PHONE, supplierPhone);

        int rowsUpdated = getContentResolver().update(mCurrentBookUri, values, null, null);

        // Show a toast message depending on whether or not the insertion was successful.
        if (rowsUpdated == 0) {

            Toast.makeText(this, getString(R.string.edited_book_failed),
                    Toast.LENGTH_SHORT).show();
        } else {

            Toast.makeText(this, getString(R.string.edited_book_success),
                    Toast.LENGTH_SHORT).show();
        }
        finish();
    }
    private void showDeleteConfirmationDialog() {
        // Create an AlertDialog.Builder and set the message, and click listeners
        // for the postivie and negative buttons on the dialog.
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.delete_dialog_msg);
        builder.setPositiveButton(R.string.delete_button, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User clicked the "Delete" button, so delete the pet.
                deleteBook();
            }
        });
        builder.setNegativeButton(R.string.cancel_delete, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User clicked the "Cancel" button, so dismiss the dialog
                // and continue editing the pet.
                if (dialog != null) {
                    dialog.dismiss();
                }
            }
        });

        // Create and show the AlertDialog
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }
    private void deleteBook() {

        int rowsDeleted = 0;
        // Only perform the delete if this is an existing pet.
        if (mCurrentBookUri != null) {
            // Call the ContentResolver to delete the pet at the given content URI.
            // Pass in null for the selection and selection args because the mCurrentPetUri
            // content URI already identifies the pet that we want.
            rowsDeleted = getContentResolver().delete(mCurrentBookUri, null, null);
        }

        // Show a toast message depending on whether or not the delete was successful.
        if (rowsDeleted == 0) {
            // If no rows were deleted, then there was an error with the delete.
            Toast.makeText(this, getString(R.string.delete_book_fail),
                    Toast.LENGTH_SHORT).show();
        } else {
            // Otherwise, the delete was successful and we can display a toast.
            Toast.makeText(this, getString(R.string.delete_book_ok),
                    Toast.LENGTH_SHORT).show();

        }
        finish();
    }
    private void showUnsavedBookDialog(
            DialogInterface.OnClickListener discardButtonClickListener) {
        // Create an AlertDialog.Builder and set the message, and click listeners
        // for the postivie and negative buttons on the dialog.
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.unsaved_changes);
        builder.setPositiveButton(R.string.discard, discardButtonClickListener);
        builder.setNegativeButton(R.string.continue_insert, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User clicked the "Keep editing" button, so dismiss the dialog
                // and continue editing the book.
                if (dialog != null) {
                    dialog.dismiss();
                }
            }
        });
        // Create and show the AlertDialog
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    /**
     * This method is called when the back button is pressed.
     */
    @Override
    public void onBackPressed() {
        // If the book hasn't changed, continue with handling back button press
        if (!mBookHasChanged) {
            super.onBackPressed();
            return;
        }

        // Otherwise if there are unsaved changes, setup a dialog to warn the user.
        // Create a click listener to handle the user confirming that changes should be discarded.
        DialogInterface.OnClickListener discardButtonClickListener =
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // User clicked "Discard" button, close the current activity.
                        finish();
                    }
                };

        // Show dialog that there are unsaved changes
        showUnsavedBookDialog(discardButtonClickListener);
    }


    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        // Since the editor shows all book attributes, define a projection that contains
        // all columns from the book table
        String[] projection = {
                BookData._ID,
                BookData.COLUMN_BOOK_TITLE,
                BookData.COLUMN_BOOK_PRICE,
                BookData.COLUMN_BOOK_QUANTITY,
                BookData.COLUMN_SUPPLIER_NAME,
                BookData.COLUMN_SUPPLIER_PHONE};

        // This loader will execute the ContentProvider's query method on a background thread
        return new CursorLoader(this,   // Parent activity context
                mCurrentBookUri,         // Query the content URI for the current book
                projection,             // Columns to include in the resulting Cursor
                null,                   // No selection clause
                null,                   // No selection arguments
                null);                  // Default sort order
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {
        // Bail early if the cursor is null or there is less than 1 row in the cursor
        if (cursor == null || cursor.getCount() < 1) {
            return;
        }

        // Proceed with moving to the first row of the cursor and reading data from it
        // (This should be the only row in the cursor)
        if (cursor.moveToFirst()) {
            // Find the columns of book attributes that we're interested in
            int titleColumnIndex = cursor.getColumnIndex(BookData.COLUMN_BOOK_TITLE);
            int priceColumnIndex = cursor.getColumnIndex(BookData.COLUMN_BOOK_PRICE);
            int quantityColumnIndex = cursor.getColumnIndex(BookData.COLUMN_BOOK_QUANTITY);
            int supplierNameColumnIndex = cursor.getColumnIndex(BookData.COLUMN_SUPPLIER_NAME);
            int supplierPhoneColumnIndex = cursor.getColumnIndex(BookData.COLUMN_SUPPLIER_PHONE);


            // Extract out the values from the Cursor for the given column index

            String title = cursor.getString(titleColumnIndex);
            int price = cursor.getInt(priceColumnIndex);
            int quantity = cursor.getInt(quantityColumnIndex);
            String supplierName = cursor.getString(supplierNameColumnIndex);
            Long supplierPhone = cursor.getLong(supplierPhoneColumnIndex);

            // Update the views on the screen with the values from the database
            mTitleEditText.setText(title);
            mPriceEditText.setText(String.valueOf(price));
            mQuantityTextView.setText(String.valueOf(quantity));
            mSupplierNameEditText.setText(supplierName);
            mSupplierPhoneEditText.setText(Long.toString(supplierPhone));


        }
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        // If the loader is invalidated, clear out all the data from the input fields.
        mTitleEditText.setText("");
        mPriceEditText.setText("");
        mQuantityTextView.setText("");
        mSupplierNameEditText.setText("");
        mSupplierPhoneEditText.setText("");

    }


}
